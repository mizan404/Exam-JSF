
package com.coder;

import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
@ManagedBean
@RequestScoped
public class StudentController {
    private Student student;
    private List<Student> students;
    private String result;
    
    StudentService service=new StudentService();
    
     public void studentSave(){

        service.save(student);
        result="Insert Successfully";
    }
     
      public void deleteStudent(int id){
       service.del(new Student(id));
       result="Delete Successfullt";
    }
    
    public void updateStudent(){
        service.update(student);
        result="Update Successfully";
    }
    
    public void selectUpdate(int id){
        student=service.getById(id);
    }
     

    public Student getStudent() {
        if(student==null){
            student=new Student();
        }
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public StudentService getService() {
        return service;
    }

    public void setService(StudentService service) {
        this.service = service;
    }
    
    
    
    
    
}
